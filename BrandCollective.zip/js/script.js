window.onload = function() {
	document.documentElement.style.opacity = '1';}
